package com.example.covid_19tracker;

public class data {

    public String state;
    public int active;
    public int deceased;
    public int recovered;

    public data() {

    }

    public data(String state, int active, int deceased,int recovered) {
        this.state = state;
        this.active = active;
        this.deceased = deceased;
        this.recovered= recovered;
    }

    public String getState() {
        return state;
    }

    public void setState(String title) {
        this.state = state;
    }

    public int getActive() {
        return active;
    }

    public void setActive(int active) {
        this.active = active;
    }

    public int getDeceased() {
        return deceased;
    }

    public void setDeceased(int deceased) {
        this.deceased = deceased;
    }
    public int getRecovered() {
        return recovered;
    }

    public void setRecovered(int recovered) {
        this.recovered = recovered;
    }

}
