package com.example.covid_19tracker;

import android.content.Context;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;


import java.util.List;


public class DataAdapter extends RecyclerView.Adapter<DataAdapter.ViewHolder> {

    private Context context;
    private List<data> list;

    public DataAdapter(Context context, List<data> list) {
        this.context = context;
        this.list = list;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.single_item, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        data data = list.get(position);

        holder.textState.setText(data.getState());
        holder.textActive.setText(String.valueOf(data.getActive()));
        holder.textDeceased.setText(String.valueOf(data.getDeceased()));
        holder.textRecovered.setText(String.valueOf(data.getRecovered()));

    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public TextView textState, textActive, textDeceased, textRecovered;

        public ViewHolder(View itemView) {
            super(itemView);

            textState = itemView.findViewById(R.id.main_state);
            textActive = itemView.findViewById(R.id.main_active);
            textDeceased = itemView.findViewById(R.id.main_deceased);
            textRecovered = itemView.findViewById(R.id.main_recovered);
        }
    }

}
